/**
 * openai.ts — Shubham Motors AI Voice Agent: LLM + Knowledge Engine
 *
 * IMPROVEMENTS vs original (June 2026 audit):
 *   1. Conversation STAGE detection (connect → discover → recommend → close)
 *      injected per-turn so the LLM never pitches before discovery.
 *   2. Discovery signal tracking — budget, km/day, familyUse, currentVehicle
 *      extracted server-side and injected as "WHAT YOU KNOW SO FAR".
 *   3. Emotional tone mirroring — excited/confused/impatient adjusts
 *      max_tokens and temperature per turn.
 *   4. Festival/event-aware urgency — real festival dates from KB, injected
 *      automatically when within ±30 days. Eliminates stale urgency scripts.
 *   5. Competitor intelligence capture — competitorMentioned + reason
 *      extracted in analyzeCallIntent() and ready for DB persistence.
 *   6. Language-aware WhatsApp summary prompt — analyzeCallIntent receives
 *      the session language so summaries are generated in the correct language.
 *   7. KB in-flight dedup fix — invalidateKnowledgeCache() also cancels _kbInflight.
 *   8. Higher KB cache TTL (5 min vs 1 min) — safe given admin invalidation hook.
 *   9. Proactive finance script at turn 4+ if no finance signal yet.
 *  10. Default fuel price updated to ₹108 (from May 2026 price list).
 */

import OpenAI from "openai";
import { db } from "@workspace/db";
import { knowledgeTable } from "@workspace/db";
import { and, desc, eq } from "drizzle-orm";
import { logger } from "./logger";
import { classifyTurn, tryDirectAnswer } from "./modelRouter";

// ─── Model IDs ───────────────────────────────────────────────────────────────
const MODEL_MINI = process.env.OPENAI_MODEL_MINI ?? "gpt-4o-mini";
const MODEL_PREMIUM = process.env.OPENAI_MODEL_PREMIUM ?? "gpt-4o";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY ?? process.env.OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

// ─── Cache: KB context + fuel price ─────────────────────────────────────────
// IMPROVED: TTL raised to 5 min (was 1 min). Safe because admin KB edits
// call invalidateKnowledgeCache() immediately, so stale data only persists
// for uncommitted in-flight queries (max ~500ms).
const KB_CACHE_TTL_MS = 5 * 60_000;
let _kbCache: { value: string; expiresAt: number } | null = null;
let _kbInflight: Promise<string> | null = null;
let _fuelCache: { value: number; expiresAt: number } | null = null;
let _fuelInflight: Promise<number> | null = null;

export function invalidateKnowledgeCache(): void {
  _kbCache = null;
  _fuelCache = null;
  // FIXED: also null out in-flight so the next caller re-queries from DB,
  // not from a still-running query that predates the admin edit.
  _kbInflight = null;
  _fuelInflight = null;
}

export async function buildKnowledgeContext(): Promise<string> {
  const now = Date.now();
  if (_kbCache && _kbCache.expiresAt > now) return _kbCache.value;
  if (_kbInflight) return _kbInflight;
  _kbInflight = (async () => {
    const items = await db.select().from(knowledgeTable)
      .where(and(eq(knowledgeTable.isActive, true), eq(knowledgeTable.requiresReview, false)));
    const value = items.length === 0 ? "" : items
      .map((i) => `[${i.category.toUpperCase()}] ${i.title}: ${i.content}`)
      .join("\n");
    _kbCache = { value, expiresAt: Date.now() + KB_CACHE_TTL_MS };
    return value;
  })();
  try { return await _kbInflight; }
  finally { _kbInflight = null; }
}

const FUEL_CACHE_TTL_MS = 5 * 60_000;

export async function getJaipurFuelPrice(): Promise<number> {
  const now = Date.now();
  if (_fuelCache && _fuelCache.expiresAt > now) return _fuelCache.value;
  if (_fuelInflight) return _fuelInflight;
  _fuelInflight = (async () => {
    try {
      const rows = await db.select().from(knowledgeTable)
        .where(and(
          eq(knowledgeTable.title, "fuel_price_jaipur"),
          eq(knowledgeTable.category, "market"),
          eq(knowledgeTable.isActive, true),
          eq(knowledgeTable.requiresReview, false),
        ))
        .orderBy(desc(knowledgeTable.updatedAt))
        .limit(1);
      const raw = rows[0]?.content?.trim() ?? "";
      const n = parseFloat(raw);
      // FIXED: updated fallback from ₹107 to ₹108 (May 2026 price list).
      const value = Number.isFinite(n) && n > 50 && n < 200 ? n : 108;
      _fuelCache = { value, expiresAt: Date.now() + FUEL_CACHE_TTL_MS };
      return value;
    } catch {
      return 108; // FIXED: was 107
    }
  })();
  try { return await _fuelInflight; }
  finally { _fuelInflight = null; }
}

// ─── Festival awareness ──────────────────────────────────────────────────────
// NEW: Fetch active festival KB rows (category='festival') within ±30 days.
// Format: title = 'Rakhi 2026', content = 'end_date|offer_description'
// Example content: '2026-08-09|₹2,000 cashback on Splendor and Destini'
export async function getActiveFestivalOffer(): Promise<{ name: string; offer: string; endDate: string } | null> {
  try {
    const rows = await db.select().from(knowledgeTable)
      .where(and(
        eq(knowledgeTable.category, "festival"),
        eq(knowledgeTable.isActive, true),
        eq(knowledgeTable.requiresReview, false),
      ));
    const today = new Date();
    const window = 30 * 24 * 60 * 60 * 1000; // 30 days
    for (const row of rows) {
      const parts = (row.content ?? "").split("|");
      if (parts.length < 2) continue;
      const endDate = new Date(parts[0]?.trim() ?? "");
      if (isNaN(endDate.getTime())) continue;
      const startDate = new Date(endDate.getTime() - window);
      if (today >= startDate && today <= endDate) {
        return { name: row.title, offer: parts[1]?.trim() ?? "", endDate: parts[0]?.trim() ?? "" };
      }
    }
    return null;
  } catch {
    return null;
  }
}

// ─── Types ───────────────────────────────────────────────────────────────────

export interface ConversationTurn {
  role: "user" | "assistant";
  content: string;
}

export interface LeadProfile {
  name?: string;
  interestedModel?: string | null;
  notes?: string | null;
  lastCallSummary?: string | null;
  status?: string | null;
}

// NEW: Discovery signals extracted from the live conversation.
// Populated server-side via extractDiscoverySignals() and injected into
// every LLM turn so the agent never re-asks what it already knows.
export interface DiscoverySignals {
  km?: number;              // Daily commute km
  budget?: number;          // Approximate budget in ₹
  familyUse?: boolean;      // True if customer mentioned family/wife/kids
  currentVehicle?: string;  // e.g. "Splendor", "Activa"
  financeInterest?: boolean;// True if customer asked about EMI/finance
  exchangeInterest?: boolean;// True if customer mentioned old bike exchange
  purpose?: string;         // "office" | "college" | "business" | "family"
}

// NEW: Conversation stage — computed server-side, injected into prompt.
export type ConvStage = "connect" | "discover" | "recommend" | "close";

// NEW: Emotional tone — detected from last 2 turns, adjusts LLM params.
export type EmotionalTone = "excited" | "neutral" | "confused" | "impatient";

// ─── Discovery signal extraction ─────────────────────────────────────────────
// NEW: Lightweight regex pass on customer text. No LLM call needed.
// Called by callStream.ts after every STT turn.
export function extractDiscoverySignals(
  text: string,
  existing: DiscoverySignals
): DiscoverySignals {
  const t = text.toLowerCase();
  const updated: DiscoverySignals = { ...existing };

  // Daily km
  if (!updated.km) {
    const kmMatch = t.match(/(\d{1,3})\s*(?:km|किलोमीटर|kilo)/i);
    if (kmMatch) {
      const n = parseInt(kmMatch[1]);
      if (n > 5 && n <= 500) updated.km = n;
    }
  }

  // Budget
  if (!updated.budget) {
    const budgetMatch = t.match(/(\d{1,3})(?:\s*(?:k|हज़ार|hajar|lakh|लाख))?(?:\s*(?:ka|ki|mein|tak|budget|me))/i);
    if (budgetMatch) {
      const n = parseInt(budgetMatch[1]);
      const isLakh = /lakh|लाख/.test(t.slice(budgetMatch.index ?? 0, (budgetMatch.index ?? 0) + 20));
      const isK = /\bk\b|हज़ार|hajar/.test(t.slice(budgetMatch.index ?? 0, (budgetMatch.index ?? 0) + 20));
      if (n > 0) updated.budget = isLakh ? n * 100000 : isK ? n * 1000 : n > 500 ? n : n * 1000;
    }
  }

  // Family use
  if (!updated.familyUse) {
    if (/wife|biwi|patni|bachche|family|ghar|घर|पत्नी|बच्चे|परिवार|husband|pati/i.test(t)) {
      updated.familyUse = true;
    }
  }

  // Current vehicle
  if (!updated.currentVehicle) {
    const vehicles = ["activa", "splendor", "pulsar", "apache", "jupiter", "access", "dio", "shine", "cb shine", "fz", "r15", "xoom", "glamour", "passion", "discover", "platina"];
    for (const v of vehicles) {
      if (t.includes(v)) { updated.currentVehicle = v; break; }
    }
  }

  // Finance interest
  if (!updated.financeInterest) {
    if (/\bemi\b|finance|loan|किस्त|qist|kist|finans/i.test(t)) updated.financeInterest = true;
  }

  // Exchange interest
  if (!updated.exchangeInterest) {
    if (/exchange|purani|पुरानी|trade|badlo|badalna/i.test(t)) updated.exchangeInterest = true;
  }

  // Purpose
  if (!updated.purpose) {
    if (/office|daftar|daftar|naukri|job|काम|work/i.test(t)) updated.purpose = "office";
    else if (/college|school|पढ़ाई|padhai|university/i.test(t)) updated.purpose = "college";
    else if (/delivery|business|dukaan|दुकान|shop|vyapar/i.test(t)) updated.purpose = "business";
    else if (/family|ghar|घर/i.test(t)) updated.purpose = "family";
  }

  return updated;
}

// ─── Conversation stage computation ──────────────────────────────────────────
// NEW: Server-side stage tracking. Rules (in order):
//   close:    turn >= 5 AND at least 1 discovery signal present
//   recommend:turn >= 4 AND at least 1 signal present
//   discover: turn >= 2 AND no discovery signals yet
//   connect:  turn < 2
export function computeConvStage(turn: number, signals: DiscoverySignals): ConvStage {
  const hasSignals = !!(signals.km || signals.budget || signals.familyUse || signals.currentVehicle || signals.purpose);
  if (turn >= 5 && hasSignals) return "close";
  if (turn >= 4 && hasSignals) return "recommend";
  if (turn >= 2) return "discover";
  return "connect";
}

// ─── Emotional tone detection ─────────────────────────────────────────────────
// NEW: Detect from the LAST customer message. Simple heuristics are enough.
export function detectEmotionalTone(text: string, turn: number): EmotionalTone {
  const t = text.toLowerCase().trim();
  const words = t.split(/\s+/).length;

  // Short repeated acknowledgements = impatient
  if (words <= 3 && /^(haan|ok|theek|bol|bolo|batao|haan ji|ji haan|yes|okay)[\s.!?]*$/i.test(t) && turn > 4) {
    return "impatient";
  }

  // Multiple questions or excitement signals = excited
  if ((t.match(/\?/g) ?? []).length >= 2 || /kitna|kya|kaise|mileage|emi|price|book|confirm|lena|ready/i.test(t) && words > 8) {
    return "excited";
  }

  // Confusion signals
  if (/samajh nahi|clear nahi|kya matlab|phir se|dobara|kya bola|kya kaha|nahi pata|समझ नहीं|क्या मतलब/i.test(t)) {
    return "confused";
  }

  return "neutral";
}

// ─── Format helpers ───────────────────────────────────────────────────────────

function formatLeadProfile(p?: LeadProfile): string {
  if (!p) return "";
  const lines: string[] = [];
  if (p.interestedModel) lines.push(`• Previously interested in: ${p.interestedModel}`);
  if (p.notes && p.notes.trim()) lines.push(`• Notes from past interactions: ${p.notes.trim()}`);
  if (p.lastCallSummary && p.lastCallSummary.trim()) lines.push(`• Last call summary: ${p.lastCallSummary.trim()}`);
  if (p.status && p.status !== "new") lines.push(`• CRM status: ${p.status}`);
  if (lines.length === 0) return "";
  return `\n╔══ WHAT YOU ALREADY KNOW ABOUT THIS CUSTOMER ══╗\n${lines.join("\n")}\n• Use ONLY to personalise — never invent details beyond what is listed here.\n• Reference it naturally in the FIRST 1–2 turns, not in every reply.\n╚════════════════════════════════════════════════╝`;
}

// NEW: Format discovery signals for prompt injection.
function formatDiscoverySignals(signals: DiscoverySignals): string {
  const lines: string[] = [];
  if (signals.km) lines.push(`• Daily commute: ${signals.km} km/day`);
  if (signals.budget) lines.push(`• Budget: ₹${signals.budget.toLocaleString("en-IN")}`);
  if (signals.familyUse) lines.push(`• Family use: yes (comfort matters)`);
  if (signals.currentVehicle) lines.push(`• Current vehicle: ${signals.currentVehicle}`);
  if (signals.purpose) lines.push(`• Purpose: ${signals.purpose}`);
  if (signals.financeInterest) lines.push(`• Finance interest: yes (proactively offer EMI)`);
  if (signals.exchangeInterest) lines.push(`• Exchange interest: yes (mention exchange bonus)`);
  if (lines.length === 0) return "";
  return `\n╔══ WHAT YOU KNOW FROM THIS CALL ══╗\n${lines.join("\n")}\n• Do NOT ask for information already listed above.\n• Use these facts to personalise your recommendation.\n╚══════════════════════════════════╝`;
}

// NEW: Stage-specific instructions injected per turn.
function formatStageInstructions(stage: ConvStage, addressForm: string): string {
  const instructions: Record<ConvStage, string> = {
    connect:
      `CURRENT STAGE: CONNECT (Turn 1-2)\n` +
      `YOUR ONLY JOB this turn: warm greeting + ask 1 discovery question.\n` +
      `Good opening: "aaj scooter ke liye hai ya bike? Aur khud ke liye hai ya family ke liye?"\n` +
      `DO NOT pitch any specific model or price yet. DO NOT mention EMI yet.`,
    discover:
      `CURRENT STAGE: DISCOVER (Turn 2-4)\n` +
      `YOUR ONLY JOB this turn: learn what ${addressForm} actually needs.\n` +
      `Ask about EXACTLY ONE of: daily km, budget, family use, or current vehicle — whichever is still unknown.\n` +
      `DO NOT pitch a model until you know at least one discovery signal.\n` +
      `If they name a model: acknowledge warmly, then still ask one discovery question before pitching.`,
    recommend:
      `CURRENT STAGE: RECOMMEND (Turn 4-6)\n` +
      `You now have enough to recommend. Name 1-2 specific Hero models with a concrete reason tied to what ${addressForm} told you.\n` +
      `Example: "60 km daily ke liye Splendor XTEC best hai — 80 kmpl deti hai, matlab ₹X/month petrol."\n` +
      `End with a soft close: test ride invitation OR WhatsApp brochure offer.`,
    close:
      `CURRENT STAGE: CLOSE (Turn 5+)\n` +
      `${addressForm} is engaged. Move them to a SPECIFIC action this turn.\n` +
      `Use an assumptive close: "Saturday subah 11 baje convenient hoga ya Sunday?" (not "kab aana chahenge?")\n` +
      `If they hesitate: offer to send WhatsApp price+EMI breakdown right now.\n` +
      `If they mention competitor or want to think: [TRANSFER] to sales senior — do not let a hot lead slip.\n` +
      `NEVER end this turn with a passive "kuch aur jaankari chahiye?" — propose a concrete next step.`,
  };
  return `\n╔══ STAGE INSTRUCTIONS ══╗\n${instructions[stage]}\n╚════════════════════════╝`;
}

// NEW: Festival urgency injection.
function formatFestivalOffer(festival: { name: string; offer: string; endDate: string } | null): string {
  if (!festival) return "";
  const endDate = new Date(festival.endDate);
  const daysLeft = Math.ceil((endDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
  return `\n⭐ ACTIVE FESTIVAL OFFER: ${festival.name} — ${festival.offer}. Valid till ${festival.endDate} (${daysLeft} days left).\n` +
    `Use URGENCY CLOSE for this: "Ye ${festival.name} offer ${daysLeft} din mein khatam ho rahi hai — abhi book karwa lein toh full benefit milega."`;
}

// NEW: Proactive finance nudge injected at turn 4+ if no finance signal yet.
function formatFinanceNudge(turn: number, signals: DiscoverySignals, addressForm: string): string {
  if (turn < 4 || signals.financeInterest) return "";
  return `\n💡 FINANCE NUDGE: ${addressForm} has not asked about EMI yet. After your main reply, add ONE proactive finance line:\n` +
    `"${addressForm}, agar EMI mein lena ho toh sirf ₹20,000 down payment se bhi le sakte hain — Hero FinCorp se 30 minute mein approval ho jaata hai. Batau?"`;
}

// ─── Public API ──────────────────────────────────────────────────────────────

export async function generateAgentReply(
  customerText: string,
  conversationHistory: ConversationTurn[],
  leadName: string,
  language: string,
  leadProfile?: LeadProfile,
  discoverySignals?: DiscoverySignals,
  convStage?: ConvStage,
  emotionalTone?: EmotionalTone,
  pendingQuestion?: string,
): Promise<string> {
  const [knowledge, fuelPrice, festival] = await Promise.all([
    buildKnowledgeContext(),
    getJaipurFuelPrice(),
    getActiveFestivalOffer(),
  ]);

  const addressForm = leadName === "Sir" ? "सर" : `${leadName} जी`;
  const systemPrompt = await buildSystemPrompt(
    addressForm, language, knowledge, fuelPrice, leadProfile,
    discoverySignals ?? {}, convStage ?? "connect",
    emotionalTone ?? "neutral", festival,
    conversationHistory.length, pendingQuestion,
  );

  const tier = classifyTurn(customerText, conversationHistory);
  const model = tier === "premium" ? MODEL_PREMIUM : MODEL_MINI;
  const tone = emotionalTone ?? "neutral";
  const tokenMap: Record<EmotionalTone, number> = { excited: 90, neutral: 75, confused: 65, impatient: 55 };
  const tempMap: Record<EmotionalTone, number> = { excited: 0.88, neutral: 0.75, confused: 0.55, impatient: 0.65 };

  const messages: OpenAI.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
    ...conversationHistory.map((t) => ({ role: t.role, content: t.content })),
    { role: "user", content: customerText },
  ];

  const response = await openai.chat.completions.create({
    model, messages,
    max_tokens: tokenMap[tone],
    temperature: tempMap[tone],
  });

  logger.info({ tier, model, tone }, "Agent reply");
  return response.choices[0]?.message?.content ?? "जी बोलिए, मैं सुन रही हूँ।";
}

export async function* generateAgentReplyStream(
  customerText: string,
  conversationHistory: ConversationTurn[],
  leadName: string,
  language: string,
  leadProfile?: LeadProfile,
  discoverySignals?: DiscoverySignals,
  convStage?: ConvStage,
  emotionalTone?: EmotionalTone,
  pendingQuestion?: string,
): AsyncGenerator<string, void, void> {
  const [knowledge, fuelPrice, festival] = await Promise.all([
    buildKnowledgeContext(),
    getJaipurFuelPrice(),
    getActiveFestivalOffer(),
  ]);

  const addressForm = leadName === "Sir" ? "सर" : `${leadName} जी`;
  const tone = emotionalTone ?? "neutral";
  const tokenMap: Record<EmotionalTone, number> = { excited: 90, neutral: 75, confused: 65, impatient: 55 };
  const tempMap: Record<EmotionalTone, number> = { excited: 0.88, neutral: 0.75, confused: 0.55, impatient: 0.65 };

  const systemPrompt = await buildSystemPrompt(
    addressForm, language, knowledge, fuelPrice, leadProfile,
    discoverySignals ?? {}, convStage ?? "connect",
    tone, festival, conversationHistory.length, pendingQuestion,
  );

  const tier = classifyTurn(customerText, conversationHistory);
  const model = tier === "premium" ? MODEL_PREMIUM : MODEL_MINI;

  const messages: OpenAI.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
    ...conversationHistory.map((t) => ({ role: t.role, content: t.content })),
    { role: "user", content: customerText },
  ];

  const stream = await openai.chat.completions.create({
    model,
    messages,
    max_tokens: tokenMap[tone],
    temperature: tempMap[tone],
    stream: true,
  });

  let buf = "";
  let totalChars = 0;
  let isTransfer = false;
  const SENTENCE_END = /[.!?]\s|।|\n/;
  const MIN_SENTENCE_CHARS = 6;

  for await (const part of stream) {
    const delta = part.choices[0]?.delta?.content ?? "";
    if (!delta) continue;
    buf += delta;
    totalChars += delta.length;

    if (!isTransfer && totalChars >= 10 && /^\s*\[TRANSFER/i.test(buf)) {
      isTransfer = true;
    }
    if (isTransfer) continue;

    while (true) {
      const m = buf.match(SENTENCE_END);
      if (!m || m.index === undefined) break;
      const cut = m.index + m[0].length;
      const sentence = buf.slice(0, cut).trim();
      buf = buf.slice(cut);
      if (sentence.length >= MIN_SENTENCE_CHARS) {
        yield sentence;
      } else if (sentence) {
        buf = sentence + " " + buf;
        break;
      }
    }
  }

  const tail = buf.trim();
  if (tail) yield tail;
  logger.info({ tier, model, tone, chars: totalChars, transfer: isTransfer }, "Hybrid router (stream) → done");
}

// ─── System prompt builder ────────────────────────────────────────────────────
// IMPROVED: Now receives stage, discoverySignals, tone, festival context.
// All new context is INJECTED as structured blocks — the core Sakshi persona
// is unchanged so existing behaviour is preserved; new blocks extend it.
async function buildSystemPrompt(
  addressForm: string,
  language: string,
  knowledge: string,
  fuelPrice: number,
  leadProfile: LeadProfile | undefined,
  signals: DiscoverySignals,
  stage: ConvStage,
  tone: EmotionalTone,
  festival: { name: string; offer: string; endDate: string } | null,
  turn: number,
  pendingQuestion?: string,
): Promise<string> {
  const merged = knowledge && knowledge.trim()
    ? `${knowledge}`
    : "";

  const toneInstruction = tone === "confused"
    ? "\n⚠️ TONE: Customer confused hai. Simple Hindi, short sentences, confirm karo ki samjhe."
    : tone === "impatient"
    ? "\n⚠️ TONE: Customer jaldi mein hai — 1 sentence mein point pe aao, phir direct action propose karo."
    : tone === "excited"
    ? "\n⚠️ TONE: Customer excited hai — match their energy, thoda zyada enthusiastic raho."
    : "";

  return SAKSHI_SYSTEM_PROMPT(
    addressForm, language, merged, fuelPrice, leadProfile,
    signals, stage, festival, turn, toneInstruction, pendingQuestion
  );
}

// ─── Main Sakshi system prompt ───────────────────────────────────────────────
const SAKSHI_SYSTEM_PROMPT = (
  addressForm: string,
  language: string,
  knowledge: string,
  fuelPrice: number,
  leadProfile: LeadProfile | undefined,
  signals: DiscoverySignals,
  stage: ConvStage,
  festival: { name: string; offer: string; endDate: string } | null,
  turn: number,
  toneInstruction: string,
  pendingQuestion?: string,
) => `## WHO YOU ARE
Aap SAKSHI hain — Shubham Motors ki sabse experienced sales executive. Aap ek REAL insaan hain, AI nahi. Aap phone pe ek warm, zindadil, persuasive female salesperson ki tarah baat karti hain jaise aap apne purane dost ko recommend kar rahi hain.

Aapka kaam sirf information dena NAHI hai. Aapka ASLI kaam hai:
1. Customer ko samjho — unki life, family, zaroorat
2. Unhe convince karo ki YEH bike/scooter UNKE liye kyun perfect hai
3. Showroom visit ya test ride book karo — isi call mein

## SABSE ZAROORI NIYAM — YEH PEHLE PADHO

### RULE 1: TOPIC INTERRUPT — HIGHEST PRIORITY
${pendingQuestion ? `⚡ CUSTOMER NE ABHI PUCHA: "${pendingQuestion}"
Chahe aap pehle kisi aur cheez ke baare mein bol rahe the — AB SIRF YAHI JAWAB DO.
Pehla sentence: customer ke naye sawaal ka jawab. Phir apni baat continue karo.
GALAT: "Haan Honda se compare karein toh... [3 lines]... Aur scooter mein aapke liye Destini best hai"
SAHI: "Scooter mein hamare paas Destini aur Xoom hain — Destini family ke liye best hai. Aur Honda se compare karein toh Hero ki service har gali mein milti hai."` : `Agar customer baat ke beech mein kuch naya puchhe — PEHLE unka naya sawaal answer karo, phir apni pehli baat finish karo.`}

### RULE 2: SALES CONVERSATION, NOT FAQ
Har jawab ke saath EK discovery question ya EK sales push ZAROOR hoga. Sirf information deke chup mat ho.

BAD (info-bot): "Splendor ki mileage 80 kmpl hai."
GOOD (sales executive): "Splendor 80 kmpl deti hai — aap daily kitne km chalate hain? Kyunki agar 50+ km hai toh yeh aapke liye sabse sasti bike ban jaati hai petrol mein."

### RULE 3: FAMILY BACKGROUND PROBE — EVERY CALL
Pehle 3 turns mein yeh zaroor pata karo — ek natural question se:
- Bike khud ke liye hai ya family ke liye?
- Ghar mein aur koi chalata hai?
- Kahan tak jaana hota hai daily?
Yeh info milte hi use apni recommendation mein use karo.

### RULE 4: SILENCE BREAKER — NEVER LET SILENCE WIN
Agar customer short answer deta hai (haan/theek hai/ok) — aap IMMEDIATELY ek engaging question ya observation dalo:
"Achha! Aur aapki wife ya bachche bhi chalate hain kya? Kyunki family use ke liye alag features matter karte hain."
Kabhi bhi jawab deke chup mat ho.

### RULE 5: CONVINCE, DON'T JUST INFORM
Jab bhi koi model batao — ALWAYS ek emotional ya practical reason do kyun yeh UNKE liye hai:
GALAT: "Destini 125 available hai."
SAHI: "Destini 125 ekdum perfect hai family ke liye — wide seat hai, storage bhi achha hai, aur wife bhi comfortably chala sakti hain. Aap dono ke liye ek hi scooter kaam aa jaayegi."

${formatLeadProfile(leadProfile)}
${formatDiscoverySignals(signals)}
${formatStageInstructions(stage, addressForm)}
${formatFestivalOffer(festival)}
${formatFinanceNudge(turn, signals, addressForm)}
${toneInstruction}

## CONVERSATION STYLE
- 2-3 short sentences MAXIMUM. Phone call hai, essay nahi.
- Hinglish mein baat karo — Hindi + English mix, jaise real Jaipur executive bolti hai
- Har response EK question ya EK action push ke saath khatam hona chahiye
- Fillers use karo naturally: "Achha!", "Wah!", "Bilkul!", "Samajh gayi", "Perfect"
- Customer ka naam lena: "${addressForm}" — lekin har sentence mein nahi, natural lage
- Energy: warm, confident, thodi si enthusiastic — jaise aap genuinely help karna chahti hain

## CUSTOMER BACKGROUND — ALWAYS DIG FOR THIS
Yeh 5 cheezein pata karo, conversation mein naturally:
1. **Daily use** — office/college/ghar? Kitne km?
2. **Family** — sirf khud ya wife/bachche bhi chalate hain?
3. **Current vehicle** — abhi kya hai unke paas?
4. **Budget** — rough idea lena zaroori hai
5. **Timeline** — kab lena hai? Festive season? Salary?

Jab bhi koi hint mile — use immediately use karo:
"Aapne family mention kiya — Destini 125 ekdum family scooter hai, wide seat, easy handling..."

## SCOOTER/BIKE CATEGORY QUESTIONS
Jab customer category puchhe ("scooter mein kya hai?", "bike dikhao"):
1. PEHLE ek line mein saare options batao
2. PHIR 1 targeted question puchho jo best match karne mein help kare
3. PHIR best match recommend karo with reason

"Scooter mein hamare paas 5 options hain — Pleasure+ aur Destini 110 (family/ladies ke liye), Xoom 125 aur Destini 125 (premium), aur Vida electric. ${addressForm}, scooter khud chalenge ya family ke liye bhi chahiye?"

## COMPETITOR HANDLING (Honda/Bajaj/TVS)
Kabhi insult mat karo. Seedha Hero ki strength pe aao:
"Honda bhi achhi hai — lekin Hero ki service Jaipur mein har 2 km pe milti hai. Aur resale value Hero ki zyada hoti hai Rajasthan mein. Aap kitne saal rakhenge bike?"

## SALES TECHNIQUES — USE IN EVERY CALL
**Social proof:** "Aaj subah hi ek family ne Destini 125 book ki — same requirement thi unki bhi."
**Scarcity:** "Is colour mein 2-3 pieces hi hain abhi — yeh fast jate hain."
**Urgency:** "${festival ? `${festival.name} offer chal raha hai — ${festival.offer}. Sirf ${Math.ceil((new Date(festival.endDate).getTime()-Date.now())/86400000)} din baaki hain.` : "Month-end pe price revision hone wala hai — abhi booking karana better hai."}"
**Assumptive close:** "Saturday aana easy rahega ya Sunday subah? Test ride ready rakhwa deti hoon aapke liye."
**EMI hook:** "Sirf ₹3,000-4,000 mahine mein aapki apni bike ho sakti hai — ghar ki EMI se bhi kam."

## CLOSING — MANDATORY FROM TURN 4
Turn 4 ke baad EVERY response mein ek action propose karo:
- "Showroom kab aayenge? Main test ride book kar deti hoon."
- "WhatsApp pe price list bheju aapko?"
- "Finance check kar lein pehle — 30 minute mein approve ho jaata hai."
Passive ending KABHI nahi: "koi sawaal ho toh batayein" — YEH BAND.

## OBJECTION RECOVERY
"Soch ke batata hoon" → "Bilkul! Ek cheez bataiye — finance ki wajah se soch rahe hain ya koi aur concern hai? Main wahi resolve kar deti hoon."
"Mahanga hai" → "Samajh sakti hoon. Lekin agar EMI mein dekhen toh ₹3,500/month se shuru hota hai — chai-naashte ke kharche se bhi kam daily. Aap kitna down payment comfortable feel karte hain?"
"Dusri jagah se le lenge" → "Koi baat nahi — but ek baar hamare paas aake compare karein. Test ride free hai, aur main personally best deal dilaane ki koshish karungi. Ek chance toh dijiye?"

## PRODUCT KNOWLEDGE
Petrol price Jaipur: ₹${fuelPrice}/litre

**CC = Category (jab sirf number bole toh saare options batao):**
- 100cc bikes: HF Deluxe (83kmpl, sabse sasta), Splendor+ (80kmpl, India #1), Passion+
- 125cc bikes: Super Splendor, Glamour X, Xtreme 125R (sporty)
- 160cc+: Xtreme 160R (2V/4V), Xpulse 200
- 110cc scooters: Pleasure+ (ladies/family), Destini 110, Destini Prime
- 125cc scooters: Xoom 125 (sporty/youth), Destini 125 (family/premium)
- Electric: Vida V1 Pro (110km range)

**EMI rough guide** (exact numbers KB mein hain):
- ₹90k bike → ₹20k down → ~₹3,200/month (24 months)
- ₹1L bike → ₹30k down → ~₹3,400/month (24 months)
- Always add: "exact EMI aapke CIBIL pe depend karta hai, Hero FinCorp 30 min mein approve karta hai"

## TRANSFER RULES
Yeh situations mein SIRF tag output karo, kuch nahi:
- Customer insaan se baat karna chahta hai → \`[TRANSFER] customer wants sales person\`
- Exact discount/negotiation → \`[TRANSFER] customer wants offer\`
- Finance/loan details → \`[TRANSFER:FINANCE]\`
Transfer se pehle bolna: "Ek minute ${addressForm}, main aapko hamare senior se connect karti hoon."

## DEALER KNOWLEDGE BASE
${knowledge}

Customer language: ${language}

---
YAAD RAKHO: Aap ek information kiosk NAHI hain. Aap India ki best Hero sales executive hain. Har call ek sale ka chance hai. Engage karo, convince karo, close karo.`;

CURRENT JAIPUR PETROL PRICE: ₹${fuelPrice}/L (use for fuel-savings math).
${formatLeadProfile(leadProfile)}
${formatDiscoverySignals(signals)}
${formatStageInstructions(stage, addressForm)}
${formatFestivalOffer(festival)}
${formatFinanceNudge(turn, signals, addressForm)}
${toneInstruction}

╔══ CORE STYLE ══╗
• 1–2 short sentences per reply. Phone call, not paragraph.
• Customer speaks 70%, you 30%. End with ONE clear question.
• Match customer's language exactly (Hindi/Hinglish/English).
• Address them as "${addressForm}" once or twice — not every sentence.
• Never mention being AI.
• NEVER reply with just "Hello", "Ji", "OK", "Theek hai" alone. If you didn't catch the question, ask: "${addressForm}, ek baar phir bata dijiye?" If you understood, give a substantive reply.

╔══ HOW TO READ NUMBERS — DISPLACEMENT vs MODEL NAME (CRITICAL) ══╗
When the customer says a bare number like "110", "125", "160", "200", "350", "411", they almost ALWAYS mean ENGINE DISPLACEMENT (CC), not a specific model.
WRONG: customer says "125 ke baare mein batao" → you talk only about "Xtreme 125R".
RIGHT: customer says "125 ke baare mein batao" → you list ALL Hero 125cc options in ONE short line, then ask which segment they want (bike or scooter, sporty or family).

EXAMPLES OF THE RIGHT BEHAVIOUR (ALWAYS include BOTH bikes AND scooters when CC has both):
• "125 ke baare mein batao" → "Ji ${addressForm}, 125cc mein hamare paas 5 options hain — bikes mein Super Splendor, Glamour X, aur sporty Xtreme 125R; scooters mein Xoom 125 aur Destini 125. Aap bike dekhna chahenge ya scooter, aur use family ke liye hai ya khud ke liye?"
• "110 dekhna hai" → "110cc mein bikes — Splendor Plus aur HF Deluxe; scooters — Pleasure Plus aur Destini 110. Aapko bike chahiye ya scooter?"
• "160 batao" → "160cc mein hamari Xtreme 160R 2V aur 4V dono available hain — sporty riding ke liye. Aap commuting ke liye dekh rahe hain ya weekend rides ke liye?"

ONLY when the customer explicitly names a SPECIFIC model with the number (e.g. "Xtreme 125R", "Xoom 125", "Destini 125") — then directly answer about that model. Bare numbers = CC, NEVER one model.

╔══ HERO MASTER CATALOG (BY DISPLACEMENT) — always available ══╗
[BIKES — 100cc commuter]
  • HF Deluxe — entry-level commuter, ~83 kmpl (best mileage), most affordable Hero. Variants: Kick, DRS, DRS All Black, DRS i3S, Pro.

[BIKES — 100cc premium commuter]
  • Splendor Plus — India's #1 trusted commuter, ~80 kmpl. Variants: AHO, i3S, XTEC, XTEC 2.0.
  • Passion Plus — comfort + style commuter, ~70 kmpl.

[BIKES — 125cc commuter/style]
  • Super Splendor XTEC — 125cc smooth power + 65 kmpl, family ride. Variants: XTEC, XTEC DSS.
  • Glamour X — 125cc styled commuter, ~55 kmpl. Variants: DRS Self, DSS Self.
  • Xtreme 125R — 125cc SPORTY bike, ~60 kmpl, premium segment styling. Variants: IBS, ABS, ABS Dual Channel.

[BIKES — 160cc+ sporty]
  • Xtreme 160R 2V — sporty everyday bike, ~45 kmpl. Variants: Single Disc, Double Disc.
  • Xtreme 160R 4V — premium sport variant, more power.
  • Xpulse 200 4V — adventure / off-road, ~40 kmpl.

[SCOOTERS — 110cc]
  • Pleasure Plus 110 — lightweight, female-friendly, easy city scooter, ~55 kmpl. Variants: VX Fi Digi-Analog, XTEC.
  • Destini 110 — family scooter, ~50 kmpl. Variants: VX, ZX.
// ─── EMI table (unchanged from original) ────────────────────────────────────
const EMI_FACTORS_9PA: Record<number, number> = {
  12: 0.087451, 18: 0.059602, 24: 0.045685, 36: 0.031800,
};
function _emi(principal: number, months: number): number {
  const factor = EMI_FACTORS_9PA[months];
  if (factor == null) {
    const r = 0.09 / 12;
    return Math.round(principal * (r * Math.pow(1 + r, months)) / (Math.pow(1 + r, months) - 1));
  }
  return Math.round(principal * factor);
}
function _fmtInr(n: number): string { return n.toLocaleString("en-IN"); }

function buildEmiTable(): string {
  const variants = [
    { name: "HF Deluxe Kick",          onRoad: 74698 },
    { name: "HF Deluxe DRS",           onRoad: 77423 },
    { name: "HF Deluxe Pro",           onRoad: 83348 },
    { name: "Splendor AHO",            onRoad: 91272 },
    { name: "Splendor i3S",            onRoad: 92564 },
    { name: "Splendor XTEC",           onRoad: 95377 },
    { name: "Splendor XTEC Disc",      onRoad: 98695 },
    { name: "Splendor+ XTEC 2.0",      onRoad: 97973 },
    { name: "Passion Plus",            onRoad: 94605 },
    { name: "Super Splendor XTEC",     onRoad: 98169 },
    { name: "Super Splendor XTEC DSS", onRoad: 102777 },
    { name: "Glamour X DRS",           onRoad: 104555 },
    { name: "Glamour X DSS",           onRoad: 111587 },
    { name: "Xtreme 125R IBS",         onRoad: 108088 },
    { name: "Xtreme 125R ABS",         onRoad: 113247 },
    { name: "Xtreme 125R ABS DC",      onRoad: 126275 },
    { name: "Xtreme 160R 2V SD",       onRoad: 130320 },
    { name: "Xtreme 160R 2V DD",       onRoad: 135224 },
    { name: "Xtreme 160R 4V",          onRoad: 161109 },
    { name: "Pleasure+ VX",            onRoad: 89023 },
    { name: "Pleasure XTEC",           onRoad: 93177 },
    { name: "Destini 110 VX",          onRoad: 89547 },
    { name: "Destini 110 ZX",          onRoad: 98775 },
    { name: "Destini Prime",           onRoad: 90841 },
    { name: "Destini 125 VX",          onRoad: 95857 },
    { name: "Destini 125 ZX",          onRoad: 106122 },
    { name: "Destini 125 ZX+",         onRoad: 107287 },
    { name: "Xoom 125 VX",             onRoad: 103178 },
    { name: "Xoom 125 ZX",             onRoad: 110647 },
  ];
  const downs = [20000, 30000, 50000];
  const tenures = [12, 18, 24, 36];
  const out: string[] = [];
  for (const v of variants) {
    out.push(`${v.name} — on-road ₹${_fmtInr(v.onRoad)}`);
    for (const d of downs) {
      if (d >= v.onRoad) continue;
      const loan = v.onRoad - d;
      const emis = tenures.map((m) => `${m}mo=₹${_fmtInr(_emi(loan, m))}`).join("  ");
      out.push(`  Down ₹${_fmtInr(d)} → loan ₹${_fmtInr(loan)} → EMI: ${emis}`);
    }
  }
  return out.join("\n");
}
const _EMI_TABLE = buildEmiTable();

// ─── Default KB (unchanged from original, fuel updated) ─────────────────────
const DEFAULT_HERO_KNOWLEDGE = `
[SHOWROOM DETAILS]
Shubham Motors, authorised Hero MotoCorp dealership, Jaipur.
Open Mon–Sat 9AM–7PM, Sunday 10AM–5PM. Test rides available daily.

[PRICES — ON-ROAD JAIPUR, ₹ — as of 16-May-2026. Always quote on-road by default.]

100cc BIKES
  HF Deluxe Kick (OBD-2)              74,698
  HF Deluxe DRS (OBD-2)               77,423
  HF Deluxe DRS All Black             79,100
  HF Deluxe DRS i3S                   79,578
  HF Deluxe Pro                       83,348
  Splendor AHO (OBD-2)                91,272
  Splendor i3S (OBD-2)                92,564
  Splendor i3S Additional             94,815
  Splendor XTEC (OBD-2)               95,377
  Splendor XTEC Disc                  98,695
  Splendor+ XTEC 2.0                  97,973
  Splendor+ 01                        92,693
  Passion Plus (OBD-2)                94,605

125cc BIKES
  Super Splendor XTEC (OBD-2)         98,169
  Super Splendor XTEC DSS             1,02,777
  Glamour X DRS Self                  1,04,555
  Glamour X DSS Self                  1,11,587
  Xtreme 125R IBS                     1,08,088
  Xtreme 125R ABS                     1,13,247
  Xtreme 125R ABS Dual Channel        1,26,275

160cc+ SPORTY BIKES
  Xtreme 160R 2V Single Disc          1,30,320
  Xtreme 160R 2V Double Disc          1,35,224
  Xtreme 160R 4V                      1,61,109

110cc SCOOTERS
  Destini 110 VX                      89,547
  Destini 110 ZX                      98,775
  Destini Prime (OBD-2)               90,841
  Pleasure+ VX-Fi Digi-Analog         89,023
  Pleasure XTEC                       93,177

125cc SCOOTERS
  Xoom 125 VX                         1,03,178
  Xoom 125 ZX                         1,10,647
  Destini 125 VX New                  95,857
  Destini 125 ZX New                  1,06,122
  Destini 125 ZX+ New                 1,07,287

[CURRENTLY IN STOCK — high availability]
  HF Deluxe (multiple colours, 100+ units)
  Splendor Plus (multiple colours, 100+ units), Splendor+ XTEC (20+ units)
  Passion Plus, Super Splendor XTEC
  Glamour X (Drum + Disc, multiple colours)
  Xtreme 125R (ABS + IBS, multiple colours, 50+ units)
  Xtreme 160R 2V & 4V
  Destini 110, Destini 125, Destini Prime, Pleasure+, Xoom 125
For any model not listed above, say "main exact colour stock confirm karke batati hoon" — never flat-refuse.

[PRECOMPUTED EMI TABLE — READ THESE NUMBERS DIRECTLY, NEVER COMPUTE]
9% p.a. reference rate. ALWAYS quote with disclaimer:
"ye reference EMI hai, actual rate aapke CIBIL score ke hisaab se 8.5%–12% vary kar sakta hai."
Procedure when customer asks "EMI kitna":
  1. Find the EXACT variant the customer named in the table below.
  2. Find the EXACT down-payment row and tenure column.
  3. Read the number. Quote it. NEVER add, subtract, multiply, or estimate yourself.
  4. If customer's down or tenure doesn't match a row → quote closest row + say "approximate hisaab se".

${_EMI_TABLE}

[OFFERS — always-available levers, never say "no offer"]
1. FINANCE — EMI from ₹1,590/month (₹50k principal, 36mo @ 9% reference). Zero processing fee on Hero FinCorp. 30-min approval.
2. EXCHANGE — Old two-wheeler exchange bonus ₹10,000–₹20,000 (final after physical evaluation at showroom).
3. ACCESSORIES — Free 1st service + helmet on most commuter models.
4. EXTENDED WARRANTY — 2-year extended warranty available on most variants.
For specific cash discounts / festival schemes → check admin KB or [TRANSFER] to sales.

[SHOWROOM CONTACT]
Jaipur, Rajasthan. Test rides daily 9AM–7PM. Walk-in preferred — book a slot via WhatsApp for priority.
`.trim();

// ─── Call intent analysis ─────────────────────────────────────────────────────
// IMPROVED: Added competitorMentioned, competitorReason, familyInfo, buyingTimeline.
// IMPROVED: Receives sessionLanguage so summary is generated in correct language.
export async function analyzeCallIntent(
  transcript: string,
  sessionLanguage = "hi",
): Promise<{
  intent: string;
  score: number;
  summary: string;
  followupDate: string | null;
  followupReason: string | null;
  language: string;
  familyInfo: string | null;
  preferredModel: string | null;
  objections: string[];
  competitorMentioned: string | null;
  competitorReason: string | null;
  buyingTimeline: string | null;
}> {
  const langInstruction = sessionLanguage.startsWith("hi")
    ? "Write the summary field in Hindi (Devanagari script)."
    : "Write the summary field in English.";

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: `You are a sales call analyzer for Shubham Motors (Hero MotoCorp dealer). ${langInstruction}
Analyze the transcript and return JSON with:
- intent: "hot_buy" | "interested" | "thinking" | "future_date" | "not_interested" | "wrong_number" | "needs_info"
- score: 0-100 buying intent score
- summary: 1-2 sentence call outcome summary (in the correct language as instructed above)
- followupDate: ISO date string if customer mentioned a future time, else null
- followupReason: paraphrased reason to follow up, else null
- language: detected language code (hi, en, mr, etc.)
- familyInfo: family members mentioned (spouse, kids, ages) — short string for cross-sell, else null
- preferredModel: specific Hero model customer showed most interest in, else null
- objections: array of objection strings raised (e.g. "price too high", "wants TVS comparison"), else []
- competitorMentioned: competitor brand mentioned by customer (Bajaj/TVS/Honda/Yamaha/etc.), else null
- competitorReason: why customer considered competitor (price/mileage/design/waiting), else null
- buyingTimeline: "immediate" | "15days" | "month" | "festival" | "next_year" | null

Score guide: hot_buy=85-100, interested=60-80, thinking=40-60, future_date=50-70, needs_info=30-50, not_interested=0-20`,
      },
      { role: "user", content: `Transcript:\n${transcript}` },
    ],
    response_format: { type: "json_object" },
    temperature: 0.3,
  });

  try {
    const parsed = JSON.parse(response.choices[0]?.message?.content ?? "{}");
    return {
      intent: parsed.intent ?? "needs_info",
      score: parsed.score ?? 30,
      summary: parsed.summary ?? "Call completed",
      followupDate: parsed.followupDate ?? null,
      followupReason: parsed.followupReason ?? null,
      language: parsed.language ?? "hi",
      familyInfo: parsed.familyInfo ?? null,
      preferredModel: parsed.preferredModel ?? null,
      objections: Array.isArray(parsed.objections) ? parsed.objections : [],
      competitorMentioned: parsed.competitorMentioned ?? null,
      competitorReason: parsed.competitorReason ?? null,
      buyingTimeline: parsed.buyingTimeline ?? null,
    };
  } catch {
    logger.error("Failed to parse intent analysis JSON");
    return {
      intent: "needs_info", score: 30, summary: "Call completed",
      followupDate: null, followupReason: null, language: "hi",
      familyInfo: null, preferredModel: null, objections: [],
      competitorMentioned: null, competitorReason: null, buyingTimeline: null,
    };
  }
}

// ─── Smart follow-up date computation ─────────────────────────────────────────
// NEW: Server-side follow-up date rules — do not rely on LLM guessing the date.
// Called by callStream.ts handleStop() instead of using the raw LLM date.
export function computeFollowupDate(
  intent: string,
  score: number,
  buyingTimeline: string | null,
  festivalName?: string | null,
): { date: Date; reason: string } | null {
  const now = new Date();
  const addDays = (d: Date, n: number) => new Date(d.getTime() + n * 86400000);
  const nextSalaryDay = () => {
    const d = new Date(now.getFullYear(), now.getMonth() + 1, 1, 10, 0, 0);
    return d;
  };

  // Hot buy — same day +2 hours
  if (intent === "hot_buy" || score >= 85) {
    const d = new Date(now.getTime() + 2 * 3600000);
    return { date: d, reason: "Hot lead — immediate follow-up (2 hours)" };
  }

  // Timeline-based
  if (buyingTimeline === "immediate") {
    return { date: addDays(now, 1), reason: "Customer ready to buy — next day follow-up" };
  }
  if (buyingTimeline === "15days") {
    return { date: addDays(now, 10), reason: "Customer buying in 15 days — check-in at 10 days" };
  }
  if (buyingTimeline === "month") {
    return { date: addDays(now, 22), reason: "Customer buying next month — follow-up at 22 days" };
  }
  if (buyingTimeline === "festival") {
    const festDate = addDays(now, 35); // approximate festival-season window
    return { date: festDate, reason: festivalName ? `${festivalName} season follow-up` : "Festival-season follow-up" };
  }

  // Intent-based defaults
  if (intent === "interested" || score >= 60) {
    return { date: addDays(now, 3), reason: "Warm lead — 3 day check-in" };
  }
  if (intent === "thinking" || score >= 40) {
    return { date: addDays(now, 7), reason: "Thinking lead — 7 day nurture" };
  }
  if (intent === "future_date") {
    // Salary cycle assumption
    return { date: nextSalaryDay(), reason: "Salary-cycle lead — follow-up on 1st of next month" };
  }

  return null; // not_interested / wrong_number / needs_info with no timeline
}

// ─── Self-learning (unchanged from original) ─────────────────────────────────
export async function learnFromTranscript(
  transcript: string,
  outcome: string,
  source?: string,
): Promise<void> {
  try {
    const existing = await db.select({ title: knowledgeTable.title }).from(knowledgeTable);
    const existingTitles = new Set(existing.map((r) => r.title.toLowerCase().trim()));

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You audit Hero MotoCorp dealership sales calls. Extract ONLY high-signal items the sales team must know — NOT vague impressions.

Return JSON: { "items": [{
  "type": "agent_mistake" | "price_correction" | "new_objection" | "missing_info",
  "category": "faq" | "policy" | "objection" | "models" | "price" | "general",
  "title": "<short, specific, distinctive — max 80 chars>",
  "content": "<actionable fact + the correct response the agent should give next time>",
  "evidence": "<exact verbatim quote from transcript proving this>"
}] }

STRICT RULES:
• "agent_mistake": agent gave wrong info AND customer corrected, OR agent refused a valid question.
• "price_correction": agent's price was disputed or contradicted in-call.
• "new_objection": a NEW objection phrasing the agent struggled with. NOT generic.
• "missing_info": customer asked a specific question agent couldn't answer.
• Skip impressions like "customer interested in X" — no training value.
• If nothing meets the bar, return {"items": []}. Empty is GOOD — quality over quantity.`,
        },
        { role: "user", content: `Transcript:\n${transcript}\n\nCall outcome: ${outcome}` },
      ],
      response_format: { type: "json_object" },
      temperature: 0.2,
    });

    const parsed = JSON.parse(response.choices[0]?.message?.content ?? "{}");
    const items: Array<{ type: string; category: string; title: string; content: string; evidence?: string }> = parsed.items ?? [];
    const validCats = new Set(["faq", "policy", "objection", "models", "price", "general"]);
    let inserted = 0;

    for (const item of items) {
      if (!item.title || !item.content) continue;
      const tNorm = item.title.toLowerCase().trim();
      if (existingTitles.has(tNorm)) continue;
      const category = validCats.has(item.category) ? item.category : "general";
      await db.insert(knowledgeTable).values({
        title: item.title.slice(0, 120),
        category,
        content: `[${item.type}] ${item.content}`.slice(0, 1500),
        evidence: item.evidence ? item.evidence.slice(0, 800) : null,
        source: source ?? null,
        isActive: false,
        requiresReview: true,
      });
      existingTitles.add(tNorm);
      inserted++;
    }

    if (inserted > 0) {
      logger.info({ inserted, extracted: items.length, source }, "Self-learning v2 → queued for review");
    }
  } catch (err) {
    logger.error({ err }, "Error in self-learning from transcript");
  }
}
