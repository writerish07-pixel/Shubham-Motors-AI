-- Migration: 0001_crm_intelligence_columns.sql
-- Generated: June 2026 audit
-- Adds CRM intelligence columns to leads table and retry/context columns to followups table.
-- Run with: pnpm drizzle-kit push  OR  apply manually via psql

-- ── leads table: 9 new CRM intelligence columns ──────────────────────────────
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS family_info        text,
  ADD COLUMN IF NOT EXISTS current_vehicle    text,
  ADD COLUMN IF NOT EXISTS daily_km           integer,
  ADD COLUMN IF NOT EXISTS budget             integer,
  ADD COLUMN IF NOT EXISTS competitor_mentioned text,
  ADD COLUMN IF NOT EXISTS competitor_reason  text,
  ADD COLUMN IF NOT EXISTS preferred_call_time text,
  ADD COLUMN IF NOT EXISTS occupation         text,
  ADD COLUMN IF NOT EXISTS buying_timeline    text;

-- ── followups table: retry tracking + outbound context ───────────────────────
ALTER TABLE followups
  ADD COLUMN IF NOT EXISTS attempt_count    integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS max_attempts     integer NOT NULL DEFAULT 3,
  ADD COLUMN IF NOT EXISTS last_attempt_at  timestamptz,
  ADD COLUMN IF NOT EXISTS outbound_context jsonb,
  ADD COLUMN IF NOT EXISTS channel          text NOT NULL DEFAULT 'call';

-- ── Index for faster follow-up queries ───────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_followups_status_scheduled
  ON followups (status, scheduled_at)
  WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS idx_leads_buying_timeline
  ON leads (buying_timeline)
  WHERE buying_timeline IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_leads_competitor
  ON leads (competitor_mentioned)
  WHERE competitor_mentioned IS NOT NULL;
